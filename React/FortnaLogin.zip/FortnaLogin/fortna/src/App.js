import Login from './Login/Login';



import './App.css';

function App() {
  return (
    <div>
      <Login/>
    </div>
  );
}

export default App;
